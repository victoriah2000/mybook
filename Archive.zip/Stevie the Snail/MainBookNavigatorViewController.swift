//
//  MainBookNavigatorViewController.swift
//  Stevie the Snail
//
//  Created by Victoria Heric on 3/1/17.
//  Copyright © 2017 Victoria Heric. All rights reserved.
//

import UIKit

class MainBookNavigatorViewController: UIViewController, PageViewControllerDelegate {

    let pageArray: [PageViewController] = [
        AppleShotViewController(),
        ExtTreeWideShotViewController(),
        ExtWideAngleToViewController(),
        GardenCloseUpViewController(),
        HeartbeatViewController(),
        CloseUpTreeToSunViewController(),
        ShellLiftToPathViewController(),
        SnailCrawlViewController(),
        NightViewController(),
        SunInSkyViewController(),
        OnTheMoveViewController(),
        GardenArrivalViewController(),
        GardnCloseUp2ViewController(),
        FinaleViewController(),
        TheEndViewController(),
        TitlesAndCreditsViewController()
    ]
     var currentIndex = 0

    
    @IBAction func userTappedNext(_ sender: Any) {
        let subviewController = pageArray[0]
        
        subviewController.delegate = self
        
        subviewController.view.alpha = 0
        
        addChildViewController(subviewController)
        subviewController.view.frame = view.frame
        view.addSubview(subviewController.view)
        
        UIView.animate(withDuration: 1.0) { 
            subviewController.view.alpha = 1.0
        }
    }
    
    func userWantsToGoToNextPage() {
        currentIndex += 1
        currentIndex = min(currentIndex, pageArray.count - 1)
        let subviewController = pageArray[currentIndex]
        
        subviewController.delegate = self
        
        subviewController.view.alpha = 0
        
        addChildViewController(subviewController)
        subviewController.view.frame = view.frame
        view.addSubview(subviewController.view)
        
        UIView.animate(withDuration: 1.0) {
            subviewController.view.alpha = 1.0
        }
    }
    
    func userWantsToGoToPreviousPage() {
        currentIndex -= 1
        currentIndex = min(currentIndex, pageArray.count - 1)
        let subviewController = pageArray[currentIndex]
        
        subviewController.delegate = self
        
        subviewController.view.alpha = 0
        
        addChildViewController(subviewController)
        subviewController.view.frame = view.frame
        view.addSubview(subviewController.view)
        
        UIView.animate(withDuration: 1.0) {
            subviewController.view.alpha = 1.0
        }
    }
}

