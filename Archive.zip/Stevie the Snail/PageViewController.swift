//
//  PageViewController.swift
//  Stevie the Snail
//
//  Created by Victoria Heric on 3/1/17.
//  Copyright © 2017 Victoria Heric. All rights reserved.
//

import UIKit

protocol PageViewControllerDelegate: class {
    func userWantsToGoToNextPage()
    func userWantsToGoToPreviousPage()
}

class PageViewController: UIViewController {

    weak var delegate: PageViewControllerDelegate?

}
