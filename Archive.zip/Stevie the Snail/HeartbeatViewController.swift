//
//  HeartbeatViewController.swift
//  Stevie the Snail
//
//  Created by Victoria Heric on 2/2/17.
//  Copyright © 2017 Victoria Heric. All rights reserved.
//

import UIKit

class HeartbeatViewController: PageViewController {
    @IBOutlet var heartBeat: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        heartBeatAnimation()
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func userTappedNext(_ sender: Any) { delegate?.userWantsToGoToNextPage()
    }
    
    
    @IBAction func userTappedPrevious(_ sender: Any) { delegate?.userWantsToGoToPreviousPage()
    }
    
    func heartBeatAnimation() {
        UIView.animate(withDuration: 0.50, delay: 0.2, options: [.curveEaseInOut], animations: {
            self.heartBeat.transform = CGAffineTransform(scaleX: 1.5, y: 1.5)
        }, completion: { _ in
            UIView.animate(withDuration: 0.50, delay: 0, options: [.curveEaseInOut], animations: {
                self.heartBeat.transform = .identity
            }, completion: { _ in
                self.heartBeatAnimation()
            })
        })
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
