//
//  ExtTreeWideShotViewController.swift
//  Stevie the Snail
//
//  Created by Victoria Heric on 2/2/17.
//  Copyright © 2017 Victoria Heric. All rights reserved.
//

import UIKit

class ExtTreeWideShotViewController: PageViewController {
    // MARK: IBOutlet
    @IBOutlet var ButterflyEffect: [UIImageView]!
    
    @IBOutlet var ForwardButton: UIButton!
    @IBOutlet var BackButton: UIButton!
    // MARK: Variables
    var animator: UIDynamicAnimator!
    var gravity: UIFieldBehavior?
    var views: [UIView] = []
    // MARK: Constants
    let minimumRadius: CGFloat = 60
    let radius: CGFloat = 1028
    let strength: CGFloat = 800
    let fallOff: CGFloat = 1
    let damping: CGFloat = 5
    // MARK: UIViewController
    override func viewDidLoad() {
        super.viewDidLoad()
        animator = UIDynamicAnimator(referenceView: view)
        let gestureRecognizer = UILongPressGestureRecognizer()
        gestureRecognizer.minimumPressDuration = .ulpOfOne
        gestureRecognizer.addTarget(self, action: #selector(pan(recognizer:)))
        gestureRecognizer.cancelsTouchesInView = false
        view.addGestureRecognizer(gestureRecognizer)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        guard views.count == 0 else {
            return
        }
        ButterflyEffect.forEach { view in
            let snapBehavior = UISnapBehavior(item: view, snapTo: view.center)
            snapBehavior.damping = damping
            animator.addBehavior(snapBehavior)
        }
        
    }
    
    deinit {
    }
    // MARK: Instance Methods
    @objc private func pan(recognizer: UILongPressGestureRecognizer) {
        if BackButton.bounds.contains( recognizer.location(in: BackButton)) {
            return
        }
        if ForwardButton.bounds.contains( recognizer.location(in: ForwardButton)) {
            return
        }
        switch recognizer.state {
        case .began:
            let gravity = UIFieldBehavior.radialGravityField(position: recognizer.location(in: view))
            gravity.region = UIRegion(radius: radius)
            gravity.minimumRadius = minimumRadius
            ButterflyEffect.forEach{ gravity.addItem($0) }
            gravity.strength = recognizer.numberOfTouches % 2 == 0 ? -strength : strength
            gravity.falloff = fallOff
            animator.addBehavior(gravity)
            self.gravity = gravity
        case .changed:
            gravity?.position = recognizer.location(in: view)
        case .ended, .cancelled:
            if let gravity = gravity {
                animator.removeBehavior(gravity)
            }
        default:
            break
        }
        
    }
    // MARK: IBAction

    @IBAction func userTappedNext(_ sender: Any) {
        delegate?.userWantsToGoToNextPage()
    }
    
    @IBAction func userTappedPrevious(_ sender: Any) {
        delegate?.userWantsToGoToPreviousPage()
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
